<!-- JavaScript module template -->
    function moduleName() {
      return 'Hello, World!';
    }
