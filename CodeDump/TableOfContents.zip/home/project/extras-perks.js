const fs = require('fs');
    const path = require('path');

    // Define a function to implement the ExtrasPerks
    function implementExtrasPerks() {
      // Implement the logic for the ExtrasPerks here
      console.log('ExtrasPerks implemented!');
    }

    // Call the implementExtrasPerks function
    implementExtrasPerks();
