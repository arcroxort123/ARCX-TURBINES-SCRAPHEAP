const fs = require('fs');
    const path = require('path');

    // Define a function to generate modules using the surface
    function generateModulesUsingSurface() {
      const moduleFiles = fs.readdirSync(path.join(__dirname, 'modules'));
      moduleFiles.forEach((moduleFile) => {
        const modulePath = path.join(__dirname, 'modules', moduleFile);
        const surfacePath = path.join(__dirname, 'surface', moduleFile.replace('.js', '.surface.js'));
        fs.copyFileSync(modulePath, surfacePath);
      });
    }

    // Define a function to validate modules using the surface
    function validateModulesUsingSurface() {
      const moduleFiles = fs.readdirSync(path.join(__dirname, 'surface'));
      moduleFiles.forEach((moduleFile) => {
        const modulePath = path.join(__dirname, 'surface', moduleFile);
        const validationResult = validateModuleUsingSurface(modulePath);
        if (validationResult === true) {
          console.log(`Module ${moduleFile} is valid.`);
        } else {
          console.log(`Module ${moduleFile} is invalid.`);
        }
      });
    }

    // Define a function to display the user interface
    function displayUserInterface() {
      console.log('Welcome to the Surface!');
      console.log('Please select the type of module you want to generate:');
      console.log('1. JavaScript');
      console.log('2. Python');
      console.log('3. HTML');
      const choice = readlineSync.question('Enter your choice: ');
      switch (choice) {
        case '1':
          generateJavaScriptModuleUsingSurface();
          break;
        case '2':
          generatePythonModuleUsingSurface();
          break;
        case '3':
          generateHtmlModuleUsingSurface();
          break;
        default:
          console.log('Invalid choice. Please try again.');
      }
    }

    // Call the displayUserInterface function
    displayUserInterface();
