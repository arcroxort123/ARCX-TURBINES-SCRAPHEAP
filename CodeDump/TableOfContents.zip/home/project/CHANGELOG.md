# Changelog
    * 2023-02-20: Refactored outdated code and removed deprecated dependencies.
    * 2023-02-15: Improved documentation to make it easier for users to understand how to use the Auto-Module-builder.
